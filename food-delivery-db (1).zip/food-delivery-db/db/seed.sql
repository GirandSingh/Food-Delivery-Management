-- ============================================================
-- Sample data for the Food Delivery Platform
-- Totals follow: total = subtotal + tax + delivery_charge - discount
-- ============================================================
USE food_delivery;

INSERT INTO delivery_zone (zone_name, delivery_charge) VALUES
  ('Zone A - Central', 30.00),
  ('Zone B - North',   40.00),
  ('Zone C - South',   50.00);

INSERT INTO customer (name, email, phone) VALUES
  ('Aarav Sharma', 'aarav.sharma@example.com', '9000000001'),
  ('Priya Verma',  'priya.verma@example.com',  '9000000002'),
  ('Rohan Mehta',  'rohan.mehta@example.com',  '9000000003'),
  ('Sneha Patil',  'sneha.patil@example.com',  '9000000004'),
  ('Karan Singh',  'karan.singh@example.com',  '9000000005');

INSERT INTO address (customer_id, zone_id, address_line, city, pincode) VALUES
  (1, 1, '12 Lake View Road',   'Pune', '411001'),
  (2, 2, '45 Garden Street',    'Pune', '411014'),
  (3, 1, '7 Station Road',      'Pune', '411002'),
  (4, 3, '88 Hill Side Colony', 'Pune', '411038'),
  (5, 2, '23 Market Lane',      'Pune', '411015'),
  (1, 2, '5 Office Park',       'Pune', '411014');

INSERT INTO restaurant (restaurant_name, phone, status, opening_time, closing_time) VALUES
  ('Spice Garden',  '8000000001', 'OPEN', '10:00:00', '23:00:00'),
  ('Pizza Point',   '8000000002', 'OPEN', '11:00:00', '23:30:00'),
  ('Biryani House', '8000000003', 'OPEN', '11:30:00', '22:30:00');

INSERT INTO menu (restaurant_id, menu_name, status) VALUES
  (1, 'North Indian Menu', 'ACTIVE'),
  (2, 'Pizza and Sides',   'ACTIVE'),
  (3, 'Biryani Menu',      'ACTIVE');

INSERT INTO menu_item (menu_id, item_name, price, availability_status, max_quantity) VALUES
  (1, 'Paneer Tikka',     220.00, 'AVAILABLE', 5),
  (1, 'Butter Naan',       40.00, 'AVAILABLE', 10),
  (1, 'Dal Makhani',      180.00, 'AVAILABLE', 5),
  (2, 'Margherita Pizza', 250.00, 'AVAILABLE', 5),
  (2, 'Garlic Bread',     120.00, 'AVAILABLE', 5),
  (2, 'Cold Coffee',       90.00, 'AVAILABLE', 10),
  (3, 'Chicken Biryani',  280.00, 'AVAILABLE', 5),
  (3, 'Veg Biryani',      220.00, 'AVAILABLE', 5),
  (3, 'Raita',             50.00, 'AVAILABLE', 10);

INSERT INTO driver (driver_name, phone, status, availability_status) VALUES
  ('Ramesh Yadav', '7000000001', 'ACTIVE',   'AVAILABLE'),
  ('Imran Khan',   '7000000002', 'ACTIVE',   'BUSY'),
  ('Suresh Patel', '7000000003', 'ACTIVE',   'AVAILABLE'),
  ('Anil Joshi',   '7000000004', 'INACTIVE', 'OFFLINE');

INSERT INTO driver_zone (driver_id, zone_id) VALUES
  (1, 1), (1, 2),
  (2, 2), (2, 3),
  (3, 1), (3, 3),
  (4, 1);

-- ---------- Orders (the trigger adds the PLACED status row) ----------
INSERT INTO orders (customer_id, restaurant_id, address_id, order_date, subtotal, tax, discount, delivery_charge, total_amount) VALUES
  (1, 1, 1, '2026-10-20 12:15:00', 300.00, 15.00,  0.00, 30.00, 345.00),
  (2, 2, 2, '2026-10-20 13:05:00', 370.00, 18.50, 20.00, 40.00, 408.50),
  (3, 3, 3, '2026-10-20 19:40:00', 610.00, 30.50,  0.00, 30.00, 670.50),
  (4, 1, 4, '2026-10-21 20:10:00', 300.00, 15.00,  0.00, 50.00, 365.00),
  (5, 2, 5, '2026-10-21 20:30:00', 430.00, 21.50, 30.00, 40.00, 461.50),
  (1, 3, 6, '2026-10-21 21:00:00', 220.00, 11.00,  0.00, 40.00, 271.00);

INSERT INTO order_item (order_id, item_id, quantity, unit_price, line_total) VALUES
  (1, 1, 1, 220.00, 220.00),
  (1, 2, 2,  40.00,  80.00),
  (2, 4, 1, 250.00, 250.00),
  (2, 5, 1, 120.00, 120.00),
  (3, 7, 2, 280.00, 560.00),
  (3, 9, 1,  50.00,  50.00),
  (4, 3, 1, 180.00, 180.00),
  (4, 2, 3,  40.00, 120.00),
  (5, 6, 2,  90.00, 180.00),
  (5, 4, 1, 250.00, 250.00),
  (6, 8, 1, 220.00, 220.00);

INSERT INTO payment (order_id, payment_method, amount, payment_status) VALUES
  (1, 'UPI',    345.00, 'PAID'),
  (2, 'CARD',   408.50, 'PAID'),
  (3, 'CASH',   670.50, 'PAID'),
  (4, 'UPI',    365.00, 'PAID'),
  (5, 'WALLET', 461.50, 'PAID'),
  (6, 'UPI',    271.00, 'REFUNDED');

INSERT INTO order_status_history (order_id, status, changed_at) VALUES
  (1, 'CONFIRMED',        '2026-10-20 12:17:00'),
  (1, 'PREPARING',        '2026-10-20 12:20:00'),
  (1, 'OUT_FOR_DELIVERY', '2026-10-20 12:40:00'),
  (1, 'DELIVERED',        '2026-10-20 13:00:00'),
  (2, 'CONFIRMED',        '2026-10-20 13:07:00'),
  (2, 'PREPARING',        '2026-10-20 13:12:00'),
  (2, 'OUT_FOR_DELIVERY', '2026-10-20 13:35:00'),
  (2, 'DELIVERED',        '2026-10-20 13:58:00'),
  (3, 'CONFIRMED',        '2026-10-20 19:42:00'),
  (3, 'PREPARING',        '2026-10-20 19:50:00'),
  (3, 'OUT_FOR_DELIVERY', '2026-10-20 20:15:00'),
  (3, 'DELIVERED',        '2026-10-20 20:35:00'),
  (4, 'CONFIRMED',        '2026-10-21 20:12:00'),
  (4, 'PREPARING',        '2026-10-21 20:20:00'),
  (4, 'OUT_FOR_DELIVERY', '2026-10-21 20:45:00'),
  (5, 'CONFIRMED',        '2026-10-21 20:32:00'),
  (5, 'PREPARING',        '2026-10-21 20:40:00'),
  (6, 'CANCELLED',        '2026-10-21 21:05:00');

-- Order 2 was first given to driver 1, then reassigned to driver 2
INSERT INTO delivery_assignment (order_id, driver_id, assigned_at, assignment_status) VALUES
  (1, 1, '2026-10-20 12:30:00', 'DELIVERED'),
  (2, 1, '2026-10-20 13:20:00', 'CANCELLED'),
  (2, 2, '2026-10-20 13:25:00', 'DELIVERED'),
  (3, 3, '2026-10-20 20:05:00', 'DELIVERED'),
  (4, 2, '2026-10-21 20:40:00', 'PICKED_UP');

INSERT INTO review (order_id, customer_id, rating, comment) VALUES
  (1, 1, 5, 'Hot and tasty.'),
  (2, 2, 4, 'Good pizza, arrived a little late.'),
  (3, 3, 3, NULL);
