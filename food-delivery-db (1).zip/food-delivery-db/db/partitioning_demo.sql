-- ============================================================
-- Parallel / partitioned database demo (MySQL 8)
-- InnoDB partitioned tables cannot have foreign keys, so the demo
-- uses a reporting copy of orders, partitioned by delivery zone.
-- ============================================================
USE food_delivery;

DROP TABLE IF EXISTS orders_by_zone;

CREATE TABLE orders_by_zone (
  order_id     INT           NOT NULL,
  zone_id      INT           NOT NULL,
  order_date   DATETIME      NOT NULL,
  total_amount DECIMAL(10,2) NOT NULL,
  PRIMARY KEY (order_id, zone_id)
) ENGINE=InnoDB
PARTITION BY HASH (zone_id) PARTITIONS 4;

INSERT INTO orders_by_zone (order_id, zone_id, order_date, total_amount)
SELECT o.order_id, a.zone_id, o.order_date, o.total_amount
FROM orders o
JOIN address a ON a.address_id = o.address_id;

-- Rows are spread over the partitions
SELECT PARTITION_NAME, TABLE_ROWS
FROM information_schema.PARTITIONS
WHERE TABLE_SCHEMA = 'food_delivery'
  AND TABLE_NAME   = 'orders_by_zone';

-- Partition pruning: only the partition holding zone 2 is read
EXPLAIN SELECT SUM(total_amount) FROM orders_by_zone WHERE zone_id = 2;
