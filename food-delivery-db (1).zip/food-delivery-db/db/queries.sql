-- ============================================================
-- Sample queries for the evaluation demo
-- ============================================================
USE food_delivery;

-- 1. Orders with customer and restaurant names (3-table join)
SELECT o.order_id, c.name AS customer, r.restaurant_name, o.total_amount
FROM orders o
JOIN customer c   ON c.customer_id   = o.customer_id
JOIN restaurant r ON r.restaurant_id = o.restaurant_id
ORDER BY o.order_id;

-- 2. Paid revenue per restaurant (GROUP BY + aggregate)
SELECT r.restaurant_name,
       COUNT(*)            AS paid_orders,
       SUM(o.total_amount) AS revenue
FROM orders o
JOIN restaurant r ON r.restaurant_id = o.restaurant_id
JOIN payment p    ON p.order_id      = o.order_id
WHERE p.payment_status = 'PAID'
GROUP BY r.restaurant_id, r.restaurant_name
ORDER BY revenue DESC;

-- 3. Best-selling menu items by units sold
SELECT mi.item_name, SUM(oi.quantity) AS units_sold
FROM order_item oi
JOIN menu_item mi ON mi.item_id = oi.item_id
GROUP BY mi.item_id, mi.item_name
ORDER BY units_sold DESC, mi.item_name
LIMIT 5;

-- 4. Average rating per restaurant
SELECT r.restaurant_name,
       ROUND(AVG(rv.rating), 2) AS avg_rating,
       COUNT(*)                 AS reviews
FROM review rv
JOIN orders o     ON o.order_id      = rv.order_id
JOIN restaurant r ON r.restaurant_id = o.restaurant_id
GROUP BY r.restaurant_id, r.restaurant_name
ORDER BY avg_rating DESC;

-- 5. Available drivers who can deliver in zone 2 (uses the DRIVER_ZONE junction table)
SELECT d.driver_id, d.driver_name, d.availability_status
FROM driver d
JOIN driver_zone dz ON dz.driver_id = d.driver_id
WHERE dz.zone_id = 2
  AND d.status = 'ACTIVE'
  AND d.availability_status = 'AVAILABLE';

-- 6. Full status timeline of order 1
SELECT order_id, status, changed_at
FROM order_status_history
WHERE order_id = 1
ORDER BY changed_at, history_id;

-- 7. Customers who ordered more than once (HAVING)
SELECT c.name, COUNT(*) AS total_orders
FROM customer c
JOIN orders o ON o.customer_id = c.customer_id
GROUP BY c.customer_id, c.name
HAVING COUNT(*) > 1;

-- 8. Orders that were reassigned to a different driver (subquery)
SELECT order_id, COUNT(*) AS assignments
FROM delivery_assignment
GROUP BY order_id
HAVING COUNT(*) > 1;

-- 9. Orders whose payment is not PAID
SELECT o.order_id, p.payment_status, p.amount
FROM orders o
JOIN payment p ON p.order_id = o.order_id
WHERE p.payment_status <> 'PAID';

-- 10. Using the views
SELECT * FROM v_order_summary ORDER BY order_id;
SELECT * FROM v_zone_revenue ORDER BY paid_revenue DESC;
