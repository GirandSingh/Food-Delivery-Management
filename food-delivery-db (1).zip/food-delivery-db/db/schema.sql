-- ============================================================
-- Food Delivery Platform: physical schema (MySQL 8.0.16+)
-- 14 tables in 3NF: 13 entities + DRIVER_ZONE junction table
-- ORDER is a reserved word, so that table is named `orders`.
-- ============================================================

DROP DATABASE IF EXISTS food_delivery;
CREATE DATABASE food_delivery CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE food_delivery;

-- ---------- Delivery zones ----------
CREATE TABLE delivery_zone (
  zone_id         INT AUTO_INCREMENT PRIMARY KEY,
  zone_name       VARCHAR(60)  NOT NULL UNIQUE,
  delivery_charge DECIMAL(8,2) NOT NULL CHECK (delivery_charge >= 0)
) ENGINE=InnoDB;

-- ---------- Customers and addresses ----------
CREATE TABLE customer (
  customer_id INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  email       VARCHAR(120) NOT NULL UNIQUE,
  phone       VARCHAR(15)  NOT NULL
) ENGINE=InnoDB;

CREATE TABLE address (
  address_id   INT AUTO_INCREMENT PRIMARY KEY,
  customer_id  INT          NOT NULL,
  zone_id      INT          NOT NULL,
  address_line VARCHAR(200) NOT NULL,
  city         VARCHAR(60)  NOT NULL,
  pincode      CHAR(6)      NOT NULL,
  CONSTRAINT fk_address_customer FOREIGN KEY (customer_id)
    REFERENCES customer(customer_id) ON DELETE CASCADE,
  CONSTRAINT fk_address_zone FOREIGN KEY (zone_id)
    REFERENCES delivery_zone(zone_id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ---------- Restaurants, menus and items ----------
CREATE TABLE restaurant (
  restaurant_id   INT AUTO_INCREMENT PRIMARY KEY,
  restaurant_name VARCHAR(100) NOT NULL,
  phone           VARCHAR(15)  NOT NULL,
  status          ENUM('OPEN','CLOSED') NOT NULL DEFAULT 'OPEN',
  opening_time    TIME NOT NULL,
  closing_time    TIME NOT NULL
) ENGINE=InnoDB;

CREATE TABLE menu (
  menu_id       INT AUTO_INCREMENT PRIMARY KEY,
  restaurant_id INT NOT NULL,
  menu_name     VARCHAR(80) NOT NULL,
  status        ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  CONSTRAINT fk_menu_restaurant FOREIGN KEY (restaurant_id)
    REFERENCES restaurant(restaurant_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE menu_item (
  item_id             INT AUTO_INCREMENT PRIMARY KEY,
  menu_id             INT NOT NULL,
  item_name           VARCHAR(100) NOT NULL,
  price               DECIMAL(8,2) NOT NULL CHECK (price > 0),
  availability_status ENUM('AVAILABLE','UNAVAILABLE') NOT NULL DEFAULT 'AVAILABLE',
  max_quantity        INT NOT NULL DEFAULT 10 CHECK (max_quantity > 0),
  CONSTRAINT fk_item_menu FOREIGN KEY (menu_id)
    REFERENCES menu(menu_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- Orders ----------
CREATE TABLE orders (
  order_id        INT AUTO_INCREMENT PRIMARY KEY,
  customer_id     INT NOT NULL,
  restaurant_id   INT NOT NULL,
  address_id      INT NOT NULL,
  order_date      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  subtotal        DECIMAL(10,2) NOT NULL CHECK (subtotal >= 0),
  tax             DECIMAL(10,2) NOT NULL DEFAULT 0 CHECK (tax >= 0),
  discount        DECIMAL(10,2) NOT NULL DEFAULT 0 CHECK (discount >= 0),
  delivery_charge DECIMAL(10,2) NOT NULL DEFAULT 0 CHECK (delivery_charge >= 0),
  total_amount    DECIMAL(10,2) NOT NULL,
  CONSTRAINT chk_orders_total
    CHECK (total_amount = subtotal + tax + delivery_charge - discount),
  CONSTRAINT fk_orders_customer FOREIGN KEY (customer_id)
    REFERENCES customer(customer_id) ON DELETE RESTRICT,
  CONSTRAINT fk_orders_restaurant FOREIGN KEY (restaurant_id)
    REFERENCES restaurant(restaurant_id) ON DELETE RESTRICT,
  CONSTRAINT fk_orders_address FOREIGN KEY (address_id)
    REFERENCES address(address_id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE INDEX idx_orders_date ON orders(order_date);

CREATE TABLE order_item (
  order_item_id INT AUTO_INCREMENT PRIMARY KEY,
  order_id      INT NOT NULL,
  item_id       INT NOT NULL,
  quantity      INT NOT NULL CHECK (quantity > 0),
  unit_price    DECIMAL(8,2) NOT NULL CHECK (unit_price > 0),
  line_total    DECIMAL(10,2) NOT NULL,
  CONSTRAINT chk_line_total CHECK (line_total = quantity * unit_price),
  CONSTRAINT uq_order_item UNIQUE (order_id, item_id),
  CONSTRAINT fk_oi_order FOREIGN KEY (order_id)
    REFERENCES orders(order_id) ON DELETE CASCADE,
  CONSTRAINT fk_oi_item FOREIGN KEY (item_id)
    REFERENCES menu_item(item_id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE payment (
  payment_id     INT AUTO_INCREMENT PRIMARY KEY,
  order_id       INT NOT NULL UNIQUE,
  payment_method ENUM('UPI','CARD','CASH','WALLET') NOT NULL,
  amount         DECIMAL(10,2) NOT NULL CHECK (amount >= 0),
  payment_status ENUM('PENDING','PAID','FAILED','REFUNDED') NOT NULL DEFAULT 'PENDING',
  CONSTRAINT fk_payment_order FOREIGN KEY (order_id)
    REFERENCES orders(order_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE review (
  review_id   INT AUTO_INCREMENT PRIMARY KEY,
  order_id    INT NOT NULL UNIQUE,
  customer_id INT NOT NULL,
  rating      TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment     VARCHAR(500) NULL,
  CONSTRAINT fk_review_order FOREIGN KEY (order_id)
    REFERENCES orders(order_id) ON DELETE CASCADE,
  CONSTRAINT fk_review_customer FOREIGN KEY (customer_id)
    REFERENCES customer(customer_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE order_status_history (
  history_id INT AUTO_INCREMENT PRIMARY KEY,
  order_id   INT NOT NULL,
  status     ENUM('PLACED','CONFIRMED','PREPARING','OUT_FOR_DELIVERY','DELIVERED','CANCELLED') NOT NULL,
  changed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_history_order FOREIGN KEY (order_id)
    REFERENCES orders(order_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- Drivers and delivery ----------
CREATE TABLE driver (
  driver_id           INT AUTO_INCREMENT PRIMARY KEY,
  driver_name         VARCHAR(100) NOT NULL,
  phone               VARCHAR(15)  NOT NULL,
  status              ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  availability_status ENUM('AVAILABLE','BUSY','OFFLINE') NOT NULL DEFAULT 'OFFLINE'
) ENGINE=InnoDB;

-- Junction table: resolves DRIVER (M) : (N) DELIVERY_ZONE
CREATE TABLE driver_zone (
  driver_id INT NOT NULL,
  zone_id   INT NOT NULL,
  PRIMARY KEY (driver_id, zone_id),
  CONSTRAINT fk_dz_driver FOREIGN KEY (driver_id)
    REFERENCES driver(driver_id) ON DELETE CASCADE,
  CONSTRAINT fk_dz_zone FOREIGN KEY (zone_id)
    REFERENCES delivery_zone(zone_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE delivery_assignment (
  assignment_id     INT AUTO_INCREMENT PRIMARY KEY,
  order_id          INT NOT NULL,
  driver_id         INT NOT NULL,
  assigned_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  assignment_status ENUM('ASSIGNED','PICKED_UP','DELIVERED','CANCELLED') NOT NULL DEFAULT 'ASSIGNED',
  CONSTRAINT fk_da_order FOREIGN KEY (order_id)
    REFERENCES orders(order_id) ON DELETE CASCADE,
  CONSTRAINT fk_da_driver FOREIGN KEY (driver_id)
    REFERENCES driver(driver_id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE INDEX idx_da_status ON delivery_assignment(assignment_status);

-- ---------- Trigger: every new order starts with status PLACED ----------
DELIMITER $$
CREATE TRIGGER trg_orders_after_insert
AFTER INSERT ON orders
FOR EACH ROW
BEGIN
  INSERT INTO order_status_history (order_id, status, changed_at)
  VALUES (NEW.order_id, 'PLACED', NEW.order_date);
END$$
DELIMITER ;

-- ---------- Views ----------
CREATE VIEW v_order_summary AS
SELECT o.order_id,
       o.order_date,
       c.name            AS customer_name,
       r.restaurant_name,
       z.zone_name,
       o.total_amount,
       (SELECT h.status
          FROM order_status_history h
         WHERE h.order_id = o.order_id
         ORDER BY h.changed_at DESC, h.history_id DESC
         LIMIT 1)        AS current_status
FROM orders o
JOIN customer c      ON c.customer_id   = o.customer_id
JOIN restaurant r    ON r.restaurant_id = o.restaurant_id
JOIN address a       ON a.address_id    = o.address_id
JOIN delivery_zone z ON z.zone_id       = a.zone_id;

CREATE VIEW v_zone_revenue AS
SELECT z.zone_id,
       z.zone_name,
       COUNT(DISTINCT o.order_id) AS total_orders,
       COALESCE(SUM(CASE WHEN p.payment_status = 'PAID' THEN o.total_amount END), 0) AS paid_revenue
FROM delivery_zone z
LEFT JOIN address a ON a.zone_id    = z.zone_id
LEFT JOIN orders o  ON o.address_id = a.address_id
LEFT JOIN payment p ON p.order_id   = o.order_id
GROUP BY z.zone_id, z.zone_name;
