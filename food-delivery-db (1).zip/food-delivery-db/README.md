# Food Delivery Platform Database

DBMS mid-evaluation project. A relational database for a food delivery platform:
customers, restaurants, menus, orders, payments, reviews, drivers and delivery zones.

**Team:** [team members]  
**Subject teacher:** [teacher name]

## Repository layout

```
docs/                     ER diagrams, normalization worksheets, PPT, report, data dictionary
db/schema.sql             Physical schema (14 tables, constraints, indexes, trigger, 2 views)
db/seed.sql               Sample data (5 customers, 3 restaurants, 6 orders, 4 drivers)
db/queries.sql            Demo queries (joins, aggregates, HAVING, views)
db/partitioning_demo.sql  Parallel database idea: hash partitioning by delivery zone
docker-compose.yml        MySQL 8 container that loads schema and seed data
.github/workflows/        GitHub Actions pipeline that rebuilds the database on every push
```

## Run it locally

With Docker:

```bash
docker compose up -d
docker compose exec db mysql -uroot -proot food_delivery -e "SHOW TABLES;"
docker compose exec -T db mysql -uroot -proot < db/queries.sql
```

Without Docker (MySQL 8.0.16 or newer installed):

```bash
mysql -uroot -p < db/schema.sql
mysql -uroot -p < db/seed.sql
mysql -uroot -p < db/queries.sql
```

## Design summary

- 13 entities from the ER diagram plus one junction table, `driver_zone`, giving 14 tables.
- `ORDER` is a reserved SQL word, so the table is named `orders`.
- Many-to-many relationships are resolved by `order_item` (order and menu item) and `driver_zone` (driver and zone).
- Normalized step by step to 3NF/BCNF (see the normalization worksheet). Two deliberate exceptions: `address` keeps `city` next to `pincode`, and the derived columns below are stored. `orders.delivery_charge` and `order_item.unit_price` store the value at the time of the order, so old orders keep their original price. `total_amount` and `line_total` are derived values stored for billing history and protected by CHECK constraints.
- A trigger adds the `PLACED` status row to `order_status_history` when an order is inserted.
- Views: `v_order_summary` and `v_zone_revenue`.

## Continuous integration

On every push, GitHub Actions starts a MySQL 8 container, runs `schema.sql`, `seed.sql`, `queries.sql` and `partitioning_demo.sql`, and checks that all 14 tables exist. A failing script fails the build.

## Documents

Full data dictionary: [docs/data_dictionary.md](docs/data_dictionary.md)
