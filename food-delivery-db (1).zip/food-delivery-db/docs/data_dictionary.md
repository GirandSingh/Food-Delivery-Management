# Data Dictionary: food_delivery (MySQL 8)

PK = primary key, FK = foreign key.

## delivery_zone
| Column | Type | Constraint | Description |
|---|---|---|---|
| zone_id | INT | PK, AUTO_INCREMENT | Unique zone id |
| zone_name | VARCHAR(60) | NOT NULL, UNIQUE | Zone name |
| delivery_charge | DECIMAL(8,2) | NOT NULL, CHECK >= 0 | Delivery fee for the zone |

## customer
| Column | Type | Constraint | Description |
|---|---|---|---|
| customer_id | INT | PK, AUTO_INCREMENT | Unique customer id |
| name | VARCHAR(100) | NOT NULL | Customer name |
| email | VARCHAR(120) | NOT NULL, UNIQUE | Login and contact email |
| phone | VARCHAR(15) | NOT NULL | Contact number |

## address
| Column | Type | Constraint | Description |
|---|---|---|---|
| address_id | INT | PK, AUTO_INCREMENT | Unique address id |
| customer_id | INT | FK to customer, NOT NULL, ON DELETE CASCADE | Owner of the address |
| zone_id | INT | FK to delivery_zone, NOT NULL | Delivery zone of the address |
| address_line | VARCHAR(200) | NOT NULL | Street address |
| city | VARCHAR(60) | NOT NULL | City |
| pincode | CHAR(6) | NOT NULL | Postal code |

## restaurant
| Column | Type | Constraint | Description |
|---|---|---|---|
| restaurant_id | INT | PK, AUTO_INCREMENT | Unique restaurant id |
| restaurant_name | VARCHAR(100) | NOT NULL | Restaurant name |
| phone | VARCHAR(15) | NOT NULL | Contact number |
| status | ENUM('OPEN','CLOSED') | NOT NULL, DEFAULT 'OPEN' | Whether it accepts orders |
| opening_time | TIME | NOT NULL | Daily opening time |
| closing_time | TIME | NOT NULL | Daily closing time |

## menu
| Column | Type | Constraint | Description |
|---|---|---|---|
| menu_id | INT | PK, AUTO_INCREMENT | Unique menu id |
| restaurant_id | INT | FK to restaurant, NOT NULL, ON DELETE CASCADE | Restaurant that owns the menu |
| menu_name | VARCHAR(80) | NOT NULL | Menu name |
| status | ENUM('ACTIVE','INACTIVE') | NOT NULL, DEFAULT 'ACTIVE' | Whether the menu is shown |

## menu_item
| Column | Type | Constraint | Description |
|---|---|---|---|
| item_id | INT | PK, AUTO_INCREMENT | Unique item id |
| menu_id | INT | FK to menu, NOT NULL, ON DELETE CASCADE | Menu the item belongs to |
| item_name | VARCHAR(100) | NOT NULL | Item name |
| price | DECIMAL(8,2) | NOT NULL, CHECK > 0 | Current price |
| availability_status | ENUM('AVAILABLE','UNAVAILABLE') | NOT NULL, DEFAULT 'AVAILABLE' | Whether it can be ordered |
| max_quantity | INT | NOT NULL, DEFAULT 10, CHECK > 0 | Maximum quantity per order |

## orders
| Column | Type | Constraint | Description |
|---|---|---|---|
| order_id | INT | PK, AUTO_INCREMENT | Unique order id |
| customer_id | INT | FK to customer, NOT NULL | Who placed the order |
| restaurant_id | INT | FK to restaurant, NOT NULL | Restaurant receiving the order |
| address_id | INT | FK to address, NOT NULL | Delivery address |
| order_date | DATETIME | NOT NULL, DEFAULT current time, indexed | When the order was placed |
| subtotal | DECIMAL(10,2) | NOT NULL, CHECK >= 0 | Sum of line totals |
| tax | DECIMAL(10,2) | NOT NULL, DEFAULT 0, CHECK >= 0 | Tax amount |
| discount | DECIMAL(10,2) | NOT NULL, DEFAULT 0, CHECK >= 0 | Discount amount |
| delivery_charge | DECIMAL(10,2) | NOT NULL, DEFAULT 0, CHECK >= 0 | Zone charge at order time |
| total_amount | DECIMAL(10,2) | NOT NULL, CHECK total = subtotal + tax + delivery_charge - discount | Amount to pay |

## order_item
| Column | Type | Constraint | Description |
|---|---|---|---|
| order_item_id | INT | PK, AUTO_INCREMENT | Unique line id |
| order_id | INT | FK to orders, NOT NULL, ON DELETE CASCADE | Parent order |
| item_id | INT | FK to menu_item, NOT NULL | Ordered item |
| quantity | INT | NOT NULL, CHECK > 0 | Units ordered |
| unit_price | DECIMAL(8,2) | NOT NULL, CHECK > 0 | Price at order time |
| line_total | DECIMAL(10,2) | NOT NULL, CHECK = quantity x unit_price | Line amount |

UNIQUE (order_id, item_id): one row per item in an order.

## payment
| Column | Type | Constraint | Description |
|---|---|---|---|
| payment_id | INT | PK, AUTO_INCREMENT | Unique payment id |
| order_id | INT | FK to orders, NOT NULL, UNIQUE | Order being paid (one payment per order) |
| payment_method | ENUM('UPI','CARD','CASH','WALLET') | NOT NULL | How the customer paid |
| amount | DECIMAL(10,2) | NOT NULL, CHECK >= 0 | Amount paid |
| payment_status | ENUM('PENDING','PAID','FAILED','REFUNDED') | NOT NULL, DEFAULT 'PENDING' | Payment state |

## review
| Column | Type | Constraint | Description |
|---|---|---|---|
| review_id | INT | PK, AUTO_INCREMENT | Unique review id |
| order_id | INT | FK to orders, NOT NULL, UNIQUE | Reviewed order (one review per order) |
| customer_id | INT | FK to customer, NOT NULL | Reviewer |
| rating | TINYINT | NOT NULL, CHECK 1 to 5 | Star rating |
| comment | VARCHAR(500) | NULL | Optional text |

## order_status_history
| Column | Type | Constraint | Description |
|---|---|---|---|
| history_id | INT | PK, AUTO_INCREMENT | Unique history row id |
| order_id | INT | FK to orders, NOT NULL, ON DELETE CASCADE | Order whose status changed |
| status | ENUM('PLACED','CONFIRMED','PREPARING','OUT_FOR_DELIVERY','DELIVERED','CANCELLED') | NOT NULL | New status |
| changed_at | DATETIME | NOT NULL, DEFAULT current time | When the status changed |

## driver
| Column | Type | Constraint | Description |
|---|---|---|---|
| driver_id | INT | PK, AUTO_INCREMENT | Unique driver id |
| driver_name | VARCHAR(100) | NOT NULL | Driver name |
| phone | VARCHAR(15) | NOT NULL | Contact number |
| status | ENUM('ACTIVE','INACTIVE') | NOT NULL, DEFAULT 'ACTIVE' | Employment state |
| availability_status | ENUM('AVAILABLE','BUSY','OFFLINE') | NOT NULL, DEFAULT 'OFFLINE' | Current availability |

## driver_zone (junction table)
| Column | Type | Constraint | Description |
|---|---|---|---|
| driver_id | INT | PK part, FK to driver, ON DELETE CASCADE | Driver |
| zone_id | INT | PK part, FK to delivery_zone, ON DELETE CASCADE | Zone the driver can serve |

## delivery_assignment
| Column | Type | Constraint | Description |
|---|---|---|---|
| assignment_id | INT | PK, AUTO_INCREMENT | Unique assignment id |
| order_id | INT | FK to orders, NOT NULL, ON DELETE CASCADE | Order to deliver |
| driver_id | INT | FK to driver, NOT NULL | Assigned driver |
| assigned_at | DATETIME | NOT NULL, DEFAULT current time | When it was assigned |
| assignment_status | ENUM('ASSIGNED','PICKED_UP','DELIVERED','CANCELLED') | NOT NULL, DEFAULT 'ASSIGNED' | Assignment state |

## Trigger and views
| Object | Description |
|---|---|
| trg_orders_after_insert | After an order is inserted, adds a PLACED row to order_status_history |
| v_order_summary | Order with customer, restaurant, zone, total and current status |
| v_zone_revenue | Orders and paid revenue per delivery zone |
